# Echo server program
import socket
from time import *
from graphics import *
from kev import *

def getIPv4(textFile):
    x = open(textFile, 'r')
    x = x.read()
    x = list(x)
    for i in range(listLength(x)):
        if x[i] is 'I':
            if x[i+1] is 'P':
                if x[i+2] is 'v':
                    if x[i+3] is '4':
                        empty = ''
                        for j in range(36, 57, 1):
                            if x[i+j] != '\n':
                                empty = empty + x[i+j]
                            else:
                                empty = empty
                                break
                        return(empty)

def Recieve():    
    dataappender = ''
    while 1:
        #conn[Talker].sendall(data)
        def LetterConvert(data):
            Indexer = 0
            for qwerty in data:
                if qwerty == 'x':
                    Indexer = Indexer + 1
            return(Letters[Indexer])

        recvddata = conn.recv(1024)
        data = LetterConvert(str(recvddata))
        
        """one = (conn[1].recv(1024))"""
        if data != '`':
            dataappender = dataappender+data
            """Refresh()"""
            
        else:
            print(dataappender)
            dataappender = ''

HOST = getIPv4('ip.txt')    # The remote host
PORT = 5007       # Arbitrary non-privileged port
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.bind((HOST, PORT))
Letters = ['~','`','A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j','K','k','L','l','M','m','N','n','O','o','P','p','Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z',' ']
s.listen(1)
conn, addr = s.accept()
print(addr," has Joined the Server")

Recieve()
#conn.close()
