# Echo client program
import socket
from time import *
from graphics import *
from kev import *

def getIPv4(textFile):
    x = open(textFile, 'r')
    x = x.read()
    x = list(x)
    for i in range(listLength(x)):
        if x[i] is 'I':
            if x[i+1] is 'P':
                if x[i+2] is 'v':
                    if x[i+3] is '4':
                        empty = ''
                        for j in range(36, 57, 1):
                            if x[i+j] != '\n':
                                empty = empty + x[i+j]
                            else:
                                empty = empty
                                break
                        return(empty)

def Open():
    win = GraphWin('Welcome to Callxr IM!', 300,300)
    win.setCoords(0,0,10,10)

    Background = Image(Point(5,5), 'IMG/OpenBG.gif')
    Background.draw(win)

    YourIP = getIPv4('ip.txt')
    YourAddress = Text(Point(2.5,6), 'Your Address')
    YourAddress.setStyle('bold italic')
    YourAddress.draw(win)
    YourIPAddress = Text(Point(2.5,5.25), YourIP)    
    YourIPAddress.draw(win)

    TheirAddress = Text(Point(2.5, 4), 'Friends Address')
    TheirAddress.setStyle('bold italic')
    TheirAddress.draw(win)
    TheirIPAddress = Entry(Point(2.5, 3.25), 15)
    TheirIPAddress.setFill('White')
    TheirIPAddress.draw(win)

    GoButt = Button(win, Point(7.5, 2.5), 1.5, 1, 'Go!', 'Gray')
    GoButt.activate()

    if GoButt.clicked(win.getMouse()) is True:
        GoButt.deactivate()
        SERVIP = str(TheirIPAddress.getText())
        win.close()
        return(SERVIP)
    else:
        GoButt.deactivate()
        win.close()
        return(Open())
    

HOST = Open()   # The remote host
print(HOST)
PORT = 5007             # The same port as used by the server
Letters = ['~','`','A','a','B','b','C','c','D','d','E','e','F','f','G','g','H','h','I','i','J','j','K','k','L','l','M','m','N','n','O','o','P','p','Q','q','R','r','S','s','T','t','U','u','V','v','W','w','X','x','Y','y','Z','z',' ']
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((HOST, PORT))
while 1:
    SelectedSentence = str(input('What is the First Letter? ')+'`')
    print((SelectedSentence))
    for Dissect in SelectedSentence:
        for Compare in range(55):
            if Letters[Compare] is Dissect:
                s.sendall(bytes(Compare))
                sleep(1)
            else:
                x = 1

#data = s.recv(1024)
#s.close()
#print('Received', repr(data))
